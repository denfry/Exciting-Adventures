playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:26}},Tags:["lima","planta"]}

summon interaction ~ ~ ~ {Tags:["Lima","mini","interactive"]}
 kill @s