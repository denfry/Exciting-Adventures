playsound minecraft:block.sweet_berry_bush.place ambient @a ~ ~ ~ 1 1 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:20}},Tags:["turnip","planta"]}
summon interaction ~ ~ ~ {Tags:["Turnip","mini","interactive"]}
 kill @s