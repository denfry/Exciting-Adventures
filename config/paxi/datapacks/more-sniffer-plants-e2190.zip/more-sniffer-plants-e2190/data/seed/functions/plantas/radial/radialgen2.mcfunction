playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:9}},Tags:["radial2","planta"]}
summon interaction ~ ~ ~ {Tags:["Radial","terrestre","interactive"]}
execute as @e[tag=Radial,distance=..0.5] at @s run data merge entity @s {height:2.0}
 kill @s