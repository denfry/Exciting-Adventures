playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:7}},Tags:["radial","planta"]}
summon interaction ~ ~ ~ {Tags:["Radial","mini","interactive"]}
 kill @s