playsound minecraft:block.sweet_berry_bush.place ambient @a ~ ~ ~ 1 1 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:16}},Tags:["wulu","planta"]}
summon interaction ~ ~ ~ {Tags:["Wulu","interactive"]}
 kill @s