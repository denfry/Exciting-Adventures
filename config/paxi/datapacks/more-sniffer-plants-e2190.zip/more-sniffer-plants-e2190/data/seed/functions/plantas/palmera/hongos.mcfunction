execute unless block ~ ~-1 ~ air run setblock ~ ~ ~ minecraft:red_mushroom
kill @e[type=item,nbt={Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["palmera"]},CustomModelData:1,display:{Name:'[{"text":"palm","italic":false}]'}}}}]
kill @s