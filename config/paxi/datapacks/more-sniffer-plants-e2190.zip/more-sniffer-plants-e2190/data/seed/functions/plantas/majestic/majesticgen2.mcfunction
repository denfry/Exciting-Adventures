playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:49}},Tags:["majestic","planta"]}
execute as @e[tag=majestic,distance=..0.5] at @s run scoreboard players set @s bananas 96000
summon interaction ~ ~ ~ {Tags:["Majestic","terrestre","interactive"]}
 kill @s