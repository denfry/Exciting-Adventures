playsound minecraft:block.sweet_berry_bush.place ambient @a ~ ~ ~ 1 1 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:3}},Tags:["bumbum","planta"]}
summon interaction ~ ~ ~ {Tags:["Bumbum","terrestre","interactive"]}
 kill @s