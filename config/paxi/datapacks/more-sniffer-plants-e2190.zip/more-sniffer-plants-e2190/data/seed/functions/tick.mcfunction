execute as @e[type=minecraft:marker,tag=Hongo] at @s run function seed:plantas/pedmushroom/hongos
execute as @e[tag=BananaGen] at @s unless block ~ ~1 ~ #minecraft:leaves run kill @s
execute as @e[tag=BananaGenerator] at @s unless entity @e[tag=BananaGen,distance=..0.5] run kill @s

#bananas
execute as @a at @s if entity @s[nbt={SelectedItem: {id: "minecraft:apple", tag: {CustomModelData: 7}}}] run scoreboard players reset @s mascara
execute as @a[scores={banana=1..}] at @s if entity @s[nbt={Inventory: [{Slot: -106b, id: "minecraft:carrot_on_a_stick", tag: {CustomModelData: 1}}]}] run function seed:banana/pelar2
execute as @a[scores={banana=1..}] at @s if entity @s[nbt={SelectedItem: {id: "minecraft:carrot_on_a_stick", tag: {CustomModelData: 1}}}] run function seed:banana/pelar
execute as @a at @s unless entity @s[nbt={SelectedItem: {id: "minecraft:apple", tag: {CustomModelData: 7}}}] unless entity @s[nbt={Inventory: [{Slot: -106b, id: "minecraft:apple", tag: {CustomModelData: 7}}]}] run scoreboard players reset @s banana
#racimo
execute as @e[tag=BananaGenerator] at @s if data entity @s interaction run function seed:banana/agarrar
execute as @e[tag=BananaGenerator] at @s if data entity @s attack run function seed:banana/attack
execute as @e[tag=BananaGen,nbt={item: {id: "minecraft:air"}}] at @s run scoreboard players add @s bananas 1
execute as @e[tag=BananaGen] at @s if score @s bananas matches 4800.. run data merge entity @s {item: {id: "minecraft:apple", Count: 1, tag: {CustomModelData: 1}}}
execute as @e[tag=BananaGen] at @s unless entity @s[nbt={item: {id: "minecraft:air"}}] at @s run scoreboard players reset @s bananas

#planta base
execute as @e[tag=planta] at @s unless entity @s[tag=tijera] if block ~ ~-0.4 ~ mud run scoreboard players add @s bananas 2
execute as @e[tag=planta] at @s unless entity @s[tag=tijera] run scoreboard players add @s bananas 1
execute as @e[tag=planta] at @s if entity @e[tag=terrestre,distance=..0.5] run execute unless block ~ ~-1 ~ #seed:grass unless block ~ ~ ~ flower_pot unless block ~ ~ ~ minecraft:lily_pad run kill @s
execute as @e[tag=interactive] at @s on target run execute as @s at @s unless entity @s[nbt={SelectedItem: {id: "minecraft:shears"}}] unless entity @s[nbt={SelectedItem: {id: "minecraft:bone_meal"}}] run execute as @e[tag=interactive] at @s if data entity @s interaction run execute unless entity @e[tag=agarrar,distance=..0.5] run data remove entity @s interaction
execute as @e[tag=interactive] at @s unless entity @e[tag=tijera,distance=..0.5] on target run execute as @s[nbt={SelectedItem: {id: "minecraft:shears"}}] at @s run execute as @e[tag=interactive] at @s if data entity @s interaction run execute as @e[tag=planta,sort=nearest,limit=1,distance=..0.5] at @s run function seed:plantas/cortar
execute as @e[tag=interactive] at @s on target run execute as @s[nbt={SelectedItem: {id: "minecraft:bone_meal"}}] at @s run execute as @e[tag=interactive] at @s if data entity @s interaction run execute as @e[tag=planta,sort=nearest,limit=1,distance=..0.5] at @s run function seed:plantas/bone
execute as @e[tag=interactive,tag=!terrestre] at @s[tag=!water] unless block ~ ~ ~ farmland unless block ~ ~ ~ flower_pot run kill @e[tag=planta,distance=..0.5]
execute as @e[tag=terrestre,tag=!swampflower] at @s unless block ~ ~ ~ air unless block ~ ~ ~ flower_pot unless block ~ ~ ~ minecraft:lily_pad unless block ~ ~ ~ minecraft:light unless block ~ ~ ~ mud run kill @e[tag=planta,distance=..0.5]
execute as @e[tag=terrestre] at @s[tag=swampflower] unless block ~ ~ ~ air unless block ~ ~ ~ flower_pot unless block ~ ~ ~ water unless block ~ ~ ~ minecraft:lily_pad run kill @e[tag=planta,distance=..0.5]
execute as @e[tag=planta,tag=!terrestre] at @s[tag=!water] if block ~ ~ ~ water run kill @e[tag=planta,distance=..0.5]
execute as @e[tag=planta,tag=water] at @s unless block ~ ~-1 ~ water run kill @e[tag=planta,distance=..0.5]
execute as @e[tag=planta,tag=water] at @s unless block ~ ~ ~ air unless block ~ ~ ~ water run kill @e[tag=planta,distance=..0.5]
execute as @e[tag=water] at @s if block ~ ~0.1 ~ water run tp @s ~ ~0.1 ~

#palmera

execute as @e[tag=Palmera] at @s if score @e[tag=palmera,limit=1,distance=..0.5] bananas matches 48000..95990 run data merge entity @s {height:4.0,Tags:["Grande","Palmera","interactive","terrestre"]}
execute as @e[tag=Palmera] at @s if score @e[tag=palmera,limit=1,distance=..0.5] bananas matches 48000.. run tag @s remove mini
execute as @e[tag=palmera] at @s if score @s bananas matches 48000.. run data merge entity @s {item:{tag:{CustomModelData:2}},Tags:["grande","palmera","planta","terrestre"]}
execute as @e[tag=palmera] at @s if score @s bananas matches 96000.. run function seed:plantas/palmera/palmera
execute as @e[tag=palmera] at @s if score @s bananas matches 95990.. run tag @s remove Grande
execute as @e[type=marker,tag=palmera] at @s run function seed:plantas/palmera/palmeragen
execute as @e[tag=Palmera] at @s[tag=mini] unless entity @e[tag=palmera,distance=..0.5] run function seed:plantas/palmera/killminipalmera
execute as @e[tag=Palmera] at @s[tag=Grande] unless entity @e[tag=palmera,distance=..0.5] run function seed:plantas/palmera/killpalmera
execute as @e[tag=Palmera] at @s if data entity @s attack run kill @e[tag=palmera,distance=..0.5]
execute as @e[tag=palmera] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.3,0.0]},Tags:["tijera","palmera","planta","terrestre"]}
execute as @e[tag=palmera] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:2}},transformation:{translation:[-0.0,-0.1,0.0]},Tags:["tijera","grande","palmera","planta","terrestre"]}

#balla bum bum
function seed:plantas/bumbum/comida
function seed:plantas/bumbum/plantar
execute as @e[tag=Bumbum] at @s if data entity @s interaction run execute if entity @e[tag=bumbum,nbt={item:{tag:{CustomModelData:5}}},distance=..0.5] run function seed:plantas/bumbum/balla 
execute as @e[tag=Bumbum] at @s unless entity @e[tag=bumbum,nbt={item:{tag:{CustomModelData:4}}},distance=..0.8] run execute as @e[type=!item,type=!item_display,type=!interaction,distance=..0.8] at @s run damage @s 0.5 generic
execute as @e[tag=Bumbum] at @s unless entity @e[tag=bumbum,nbt={item:{tag:{CustomModelData:5}}},distance=..0.8] run execute as @e[type=!item,type=!item_display,type=!interaction,distance=..0.8] at @s run damage @s 0.5 generic
execute as @e[tag=Bumbum] at @s unless entity @e[tag=bumbum,nbt={item:{tag:{CustomModelData:5}}},distance=..0.8] run execute as @e[type=!item,type=!item_display,type=!interaction,distance=..0.8] at @s run damage @s 0.5 generic
execute as @e[tag=bumbum] at @s run effect give @e[distance=..0.8] slowness 1 2 true
execute as @e[tag=bumbum] at @s if block ~ ~-0.8 ~ air run kill @s

execute as @e[tag=bumbum,nbt={item: {tag: {CustomModelData: 3}}}] at @s if score @s bananas matches 24000..48000 run data merge entity @s {item: {tag: {CustomModelData: 4}}}
execute as @e[tag=bumbum] at @s if score @s bananas matches 48000.. run data merge entity @s {item: {tag: {CustomModelData: 5}}}
execute as @e[tag=bumbum] at @s if score @s bananas matches 48000.. run data merge entity @s {item: {tag: {CustomModelData: 5}},Tags:["terrestre","bumbum","planta","agarrar"]}
execute as @e[type=marker,tag=bumbum] at @s run function seed:plantas/bumbum/bumbumgen
execute as @e[tag=Bumbum] at @s unless entity @e[tag=bumbum,distance=..0.5] run function seed:plantas/bumbum/killbumbum
execute as @e[tag=Bumbum] at @s if data entity @s attack run kill @e[tag=bumbum,distance=..0.5]
execute as @e[tag=bumbum] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {Tags: ["tijera", "bumbum", "planta"]}

#radial

execute as @e[tag=Radial] at @s if score @e[tag=radial,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Radial","interactive"]}
execute as @e[tag=Radial] at @s if score @e[tag=radial,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=radial] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:7}}}
execute as @e[tag=radial] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:8}}}
execute as @e[tag=radial] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:9}},Tags:["grande","radial","planta"]}
execute as @e[type=marker,tag=radial] at @s run function seed:plantas/radial/radialgen
execute as @e[type=marker,tag=radial2] at @s run function seed:plantas/radial/radialgen2
execute as @e[tag=Radial] at @s[tag=mini] unless entity @e[tag=radial,distance=..0.5] run function seed:plantas/radial/killminiradial
execute as @e[tag=Radial] at @s[tag=Grande] unless entity @e[tag=radial,distance=..0.5] run function seed:plantas/radial/killradial
execute as @e[tag=Radial] at @s[tag=terrestre] unless entity @e[tag=radial2,distance=..0.5] run function seed:plantas/radial/killradial
execute as @e[tag=Radial] at @s if data entity @s attack run kill @e[tag=radial,distance=..0.5]
execute as @e[tag=Radial] at @s if data entity @s attack run kill @e[tag=radial2,distance=..0.5]
execute as @e[tag=radial2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:9}},Tags:["tijera","radial2","planta","terrestre"]}
execute as @e[tag=radial] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","radial","planta","terrestre"]}
execute as @e[tag=radial] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:9}},transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","grande","radial","planta","terrestre"]}

#amber

execute as @e[tag=Amber] at @s if score @e[tag=amber,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Amber","interactive"]}
execute as @e[tag=Amber] at @s if score @e[tag=amber,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=amber] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:10}}}
execute as @e[tag=amber] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:11}}}
execute as @e[tag=amber] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:12}},Tags:["grande","amber","planta"]}
execute as @e[type=marker,tag=amber] at @s run function seed:plantas/amber/ambergen
execute as @e[type=marker,tag=amber2] at @s run function seed:plantas/amber/ambergen2
execute as @e[tag=Amber] at @s[tag=mini] unless entity @e[tag=amber,distance=..0.5] run function seed:plantas/amber/killminiamber
execute as @e[tag=Amber] at @s[tag=Grande] unless entity @e[tag=amber,distance=..0.5] run function seed:plantas/amber/killamber
execute as @e[tag=Amber] at @s[tag=terrestre] unless entity @e[tag=amber2,distance=..0.5] run function seed:plantas/amber/killamber
execute as @e[tag=Amber] at @s if data entity @s attack run kill @e[tag=amber,distance=..0.5]
execute as @e[tag=Amber] at @s if data entity @s attack run kill @e[tag=amber2,distance=..0.5]
execute as @e[tag=amber2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:12}},Tags:["tijera","amber2","planta","terrestre"]}
execute as @e[tag=amber] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","amber","planta","terrestre"]}
execute as @e[tag=amber] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:12}},transformation:{translation:[0.0,0.0,0.0]},Tags:["tijera","grande","amber","planta","terrestre"]}

#orange

execute as @e[tag=Orange] at @s if score @e[tag=orange,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Orange","interactive"]}
execute as @e[tag=Orange] at @s if score @e[tag=orange,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=orange] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:13}}}
execute as @e[tag=orange] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:14}}}
execute as @e[tag=orange] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:15}},Tags:["tijera","grande","orange","planta"]}
execute as @e[type=marker,tag=orange] at @s run function seed:plantas/orange/orangegen
execute as @e[type=marker,tag=orange2] at @s run function seed:plantas/orange/orangegen2
execute as @e[tag=Orange] at @s[tag=mini] unless entity @e[tag=orange,distance=..0.5] run function seed:plantas/orange/killminiorange
execute as @e[tag=Orange] at @s[tag=Grande] unless entity @e[tag=orange,distance=..0.5] run function seed:plantas/orange/killorange
execute as @e[tag=Orange] at @s[tag=terrestre] unless entity @e[tag=orange2,distance=..0.5] run function seed:plantas/orange/killorange
execute as @e[tag=Orange] at @s if data entity @s attack run kill @e[tag=orange,distance=..0.5]
execute as @e[tag=Orange] at @s if data entity @s attack run kill @e[tag=orange2,distance=..0.5]
execute as @e[tag=orange2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:15}},Tags:["tijera","orange2","planta","terrestre"]}
execute as @e[tag=orange] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","orange","planta","terrestre"]}
execute as @e[tag=orange] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:15}},transformation:{translation:[0.0,0.0,0.0]},Tags:["tijera","grande","orange","planta","terrestre"]}

#wulu
function seed:plantas/wulu/comida
function seed:plantas/wulu/plantar
execute as @e[tag=Wulu] at @s if data entity @s interaction run execute if entity @e[tag=wulu,nbt={item:{tag:{CustomModelData:18}}},distance=..0.5] run function seed:plantas/wulu/balla
execute as @e[tag=wulu] at @s if block ~ ~-0.8 ~ air run kill @s
execute as @e[tag=wulu,nbt={item: {tag: {CustomModelData: 16}}}] at @s if score @s bananas matches 24000..48000 run data merge entity @s {item: {tag: {CustomModelData: 17}}}
execute as @e[tag=wulu] at @s if score @s bananas matches 48000.. run data merge entity @s {item: {tag: {CustomModelData: 18}},Tags:["wulu","planta","agarrar"]}
execute as @e[type=marker,tag=wulu] at @s run function seed:plantas/wulu/wulugen
execute as @e[tag=Wulu] at @s unless entity @e[tag=wulu,distance=..0.5] run function seed:plantas/wulu/killwulu
execute as @e[tag=Wulu] at @s if data entity @s attack run kill @e[tag=wulu,distance=..0.5]
execute as @e[tag=wulu] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,0.0,0.0]},Tags:["tijera","wulu","planta","terrestre"]}

#turnip
function seed:plantas/turnip/comida
function seed:plantas/turnip/plantar
execute as @e[tag=turnip] at @s unless entity @s[tag=tijera] run scoreboard players add @s bananas 1
execute as @e[tag=Turnip] at @s if score @e[tag=turnip,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {Tags:["Grande","Turnip","interactive"]}
execute as @e[tag=Turnip] at @s if score @e[tag=turnip,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=turnip] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:20}}}
execute as @e[tag=turnip] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:21}}}
execute as @e[tag=turnip] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:22}}}
execute as @e[type=marker,tag=turnip] at @s run function seed:plantas/turnip/turnipgen
execute as @e[type=marker,tag=turnip2] at @s run function seed:plantas/turnip/turnipgen2
execute as @e[tag=Turnip] at @s[tag=mini] unless entity @e[tag=turnip,distance=..0.5] run function seed:plantas/turnip/killminiturnip
execute as @e[tag=Turnip] at @s[tag=Grande] unless entity @e[tag=turnip,distance=..0.5] run function seed:plantas/turnip/turnip
execute as @e[tag=Turnip] at @s[tag=terrestre] unless entity @e[tag=turnip2,distance=..0.5] run function seed:plantas/turnip/killturnip
execute as @e[tag=Turnip] at @s if data entity @s attack run kill @e[tag=turnip,distance=..0.5]
execute as @e[tag=Turnip] at @s if data entity @s attack run kill @e[tag=turnip2,distance=..0.5]
execute as @e[tag=turnip] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","turnip","planta","terrestre"]}

#Spikeweed
scoreboard players add @e[tag=spikeweed] spikeweed 1
scoreboard players add @e[tag=spikeweed2,nbt={item:{tag:{CustomModelData:25}}}] spikeweed 1
execute as @e[tag=spikeweed] at @s if score @s spikeweed matches 1..3 run data merge entity @s {transformation:{scale:[1.0,1.0,1.0],translation:[0.0,0.0,0.0]},interpolation_duration:3,start_interpolation:0}
execute as @e[tag=spikeweed] at @s if score @s spikeweed matches 16..18 run data merge entity @s {transformation:{scale:[1.0,1.5,1.0],translation:[0.0,0.2,0.0]},interpolation_duration:3,start_interpolation:0}
execute as @e[tag=spikeweed] at @s if score @s spikeweed matches 25.. run scoreboard players set @s spikeweed 1
execute as @e[tag=spikeweed2,scores={spikeweed=1..3}] at @s unless block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{scale:[1.0,1.0,1.0],translation:[0.0,0.0,0.0]},interpolation_duration:3,start_interpolation:0}
execute as @e[tag=spikeweed2,scores={spikeweed=16..18}] at @s unless block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{scale:[1.0,1.5,1.0],translation:[0.0,0.2,0.0]},interpolation_duration:3,start_interpolation:0}
execute as @e[tag=spikeweed2] at @s if score @s spikeweed matches 25.. run scoreboard players set @s spikeweed 1
execute as @e[tag=spikeweed] at @s unless entity @s[tag=tijera] run scoreboard players add @s bananas 1
execute as @e[tag=Spikeweed] at @s if score @e[tag=spikeweed,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {Tags:["Grande","Spikeweed","interactive"]}
execute as @e[tag=Spikeweed] at @s if score @e[tag=spikeweed,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=spikeweed] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:23}}}
execute as @e[tag=spikeweed] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:24}}}
execute as @e[tag=spikeweed] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:25}}}
execute as @e[type=marker,tag=spikeweed] at @s run function seed:plantas/spikeweed/spikeweedgen
execute as @e[type=marker,tag=spikeweed2] at @s run function seed:plantas/spikeweed/spikeweedgen2
execute as @e[tag=Spikeweed] at @s[tag=mini] unless entity @e[tag=spikeweed,distance=..0.5] run function seed:plantas/spikeweed/killminispikeweed
execute as @e[tag=Spikeweed] at @s[tag=Grande] unless entity @e[tag=spikeweed,distance=..0.5] run function seed:plantas/spikeweed/killspikeweed
execute as @e[tag=Spikeweed] at @s[tag=terrestre] unless entity @e[tag=spikeweed2,distance=..0.5] run function seed:plantas/spikeweed/killspikeweed
execute as @e[tag=Spikeweed] at @s if data entity @s attack run kill @e[tag=spikeweed,distance=..0.5]
execute as @e[tag=Spikeweed] at @s if data entity @s attack run kill @e[tag=spikeweed2,distance=..0.5]
execute as @e[tag=spikeweed2,scores={spikeweed=1..15}] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{scale:[1.0,1.0,1.0],translation:[-0.03,-0.05,0.0]},Tags:["tijera","spikeweed2","planta","terrestre"],interpolation_duration:3,start_interpolation:0}
execute as @e[tag=spikeweed2,scores={spikeweed=16..}] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{scale:[1.0,1.5,1.0],translation:[-0.03,0.2,0.0]},Tags:["tijera","spikeweed2","planta","terrestre"],interpolation_duration:3,start_interpolation:0}
execute as @e[tag=Spikeweed] at @s unless entity @e[tag=spikeweed,nbt={item:{tag:{CustomModelData:23}}},distance=..0.5,scores={spikeweed=16..}] run execute as @e[type=!item,type=!item_display,type=!interaction,distance=..0.8] at @s run damage @s 0.5 generic
execute as @e[tag=Spikeweed] at @s unless entity @e[tag=spikeweed,nbt={item:{tag:{CustomModelData:24}}},distance=..0.5,scores={spikeweed=16..}] run execute as @e[type=!item,type=!item_display,type=!interaction,distance=..0.8] at @s run damage @s 1 generic
execute as @e[tag=Spikeweed] at @s unless entity @e[tag=spikeweed,nbt={item:{tag:{CustomModelData:25}}},distance=..0.5,scores={spikeweed=16..}] run execute as @e[type=!item,type=!item_display,type=!interaction,distance=..0.8] at @s run damage @s 1.5 generic
execute as @e[tag=spikeweed] at @s run effect give @e[distance=..0.5] slowness 1 2 true

#lima

execute as @e[tag=Lima] at @s if score @e[tag=lima,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Lima","interactive"]}
execute as @e[tag=Lima] at @s if score @e[tag=lima,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=lima] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:26}}}
execute as @e[tag=lima] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:27}}}
execute as @e[tag=lima] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:28}},Tags:["tijera","grande","lima","planta"]}
execute as @e[type=marker,tag=lima] at @s run function seed:plantas/lima/limagen
execute as @e[type=marker,tag=lima2] at @s run function seed:plantas/lima/limagen2
execute as @e[tag=Lima] at @s[tag=mini] unless entity @e[tag=lima,distance=..0.5] run function seed:plantas/lima/killminilima
execute as @e[tag=Lima] at @s[tag=Grande] unless entity @e[tag=lima,distance=..0.5] run function seed:plantas/lima/killlima
execute as @e[tag=Lima] at @s[tag=terrestre] unless entity @e[tag=lima2,distance=..0.5] run function seed:plantas/lima/killlima
execute as @e[tag=Lima] at @s if data entity @s attack run kill @e[tag=lima,distance=..0.5]
execute as @e[tag=Lima] at @s if data entity @s attack run kill @e[tag=lima2,distance=..0.5]
execute as @e[tag=lima2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:28}},Tags:["tijera","lima2","planta","terrestre"]}
execute as @e[tag=lima] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","lima","planta","terrestre"]}
execute as @e[tag=lima] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:28}},transformation:{translation:[0.0,0.0,0.0]},Tags:["tijera","grande","lima","planta","terrestre"]}

#swampflower

execute as @e[tag=Swampflower] at @s if score @e[tag=swampflower,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Swampflower","interactive"]}
execute as @e[tag=Swampflower] at @s if score @e[tag=swampflower,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=Swampflower] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:29}}}
execute as @e[tag=swampflower] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:30}}}
execute as @e[tag=swampflower] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:31}},Tags:["tijera","grande","swampflower","planta"]}
execute as @e[type=marker,tag=swampflower] at @s run function seed:plantas/swampflower/swampflowergen
execute as @e[type=marker,tag=swampflower2] at @s run function seed:plantas/swampflower/swampflowergen2
execute as @e[tag=Swampflower] at @s[tag=mini] unless entity @e[tag=swampflower,distance=..0.5] run function seed:plantas/swampflower/killminiswampflower
execute as @e[tag=Swampflower] at @s[tag=Grande] unless entity @e[tag=swampflower,distance=..0.5] run function seed:plantas/swampflower/killswampflower
execute as @e[tag=Swampflower] at @s[tag=terrestre] unless entity @e[tag=swampflower2,distance=..0.5] run function seed:plantas/swampflower/killswampflower
execute as @e[tag=Swampflower] at @s if data entity @s attack run kill @e[tag=swampflower,distance=..0.5]
execute as @e[tag=Swampflower] at @s if data entity @s attack run kill @e[tag=swampflower2,distance=..0.5]
execute as @e[tag=swampflower2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:31}},Tags:["tijera","swampflower2","planta","terrestre"]}
execute as @e[tag=swampflower] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","swampflower","planta","terrestre"]}
execute as @e[tag=swampflower] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:31}},transformation:{translation:[0.0,0.0,0.0]},Tags:["tijera","grande","swampflower","planta","terrestre"]}

#yellowsadness

execute as @e[tag=Yellowsadness] at @s if score @e[tag=yellowsadness,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Yellowsadness","interactive"]}
execute as @e[tag=Yellowsadness] at @s if score @e[tag=yellowsadness,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=yellowsadness] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:32}}}
execute as @e[tag=yellowsadness] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:33}}}
execute as @e[tag=yellowsadness] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:34}},Tags:["tijera","grande","yellowsadness","planta"]}
execute as @e[type=marker,tag=yellowsadness] at @s run function seed:plantas/yellowsadness/yellowsadnessgen
execute as @e[type=marker,tag=yellowsadness2] at @s run function seed:plantas/yellowsadness/yellowsadnessgen2
execute as @e[tag=Yellowsadness] at @s[tag=mini] unless entity @e[tag=yellowsadness,distance=..0.5] run function seed:plantas/yellowsadness/killminiyellowsadness
execute as @e[tag=Yellowsadness] at @s[tag=Grande] unless entity @e[tag=yellowsadness,distance=..0.5] run function seed:plantas/yellowsadness/killyellowsadness
execute as @e[tag=Yellowsadness] at @s[tag=terrestre] unless entity @e[tag=yellowsadness2,distance=..0.5] run function seed:plantas/yellowsadness/killyellowsadness
execute as @e[tag=Yellowsadness] at @s if data entity @s attack run kill @e[tag=yellowsadness,distance=..0.5]
execute as @e[tag=Yellowsadness] at @s if data entity @s attack run kill @e[tag=yellowsadness2,distance=..0.5]
execute as @e[tag=yellowsadness2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:34}},Tags:["tijera","yellowsadness2","planta","terrestre"]}
execute as @e[tag=yellowsadness] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","yellowsadness","planta","terrestre"]}
execute as @e[tag=yellowsadness] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:34}},transformation:{translation:[0.0,0.0,0.0]},Tags:["tijera","grande","yellowsadness","planta","terrestre"]}

#cuenco

execute as @e[tag=Cuenco] at @s if score @e[tag=cuenco,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {Tags:["Grande","water","Cuenco","interactive"]}
execute as @e[tag=Cuenco] at @s if score @e[tag=cuenco,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=cuenco] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:35}}}
execute as @e[tag=cuenco] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:36}}}
execute as @e[tag=cuenco] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:37}}}
execute as @e[type=marker,tag=cuenco] at @s run function seed:plantas/cuenco/cuencogen
execute as @e[type=marker,tag=cuenco2] at @s run function seed:plantas/cuenco/cuencogen2
execute as @e[tag=Cuenco] at @s[tag=mini] unless entity @e[tag=cuenco,distance=..0.5] run function seed:plantas/cuenco/killminicuenco
execute as @e[tag=Cuenco] at @s[tag=Grande] unless entity @e[tag=cuenco,distance=..0.5] run function seed:plantas/cuenco/killcuenco
execute as @e[tag=Cuenco] at @s if data entity @s attack run kill @e[tag=cuenco,distance=..0.5]


#luminous

execute as @e[tag=Luminous] at @s if score @e[tag=luminous,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {Tags:["Grande","Luminous","interactive"]}
execute as @e[tag=Luminous] at @s if score @e[tag=luminous,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=luminous] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:38}}}
execute as @e[tag=luminous] at @s if score @s bananas matches ..48000 run setblock ~ ~1 ~ light[level=3]
execute as @e[tag=luminous] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:39}}}
execute as @e[tag=luminous] at @s if score @s bananas matches 48000..96000 run execute unless block ~ ~ ~ flower_pot unless block ~ ~ ~ lily_pad unless block ~ ~ ~ farmland run setblock ~ ~ ~ light[level=6]
execute as @e[tag=luminous] at @s if score @s bananas matches 48000..96000 run execute if block ~ ~ ~ flower_pot if block ~ ~ ~ lily_pad if block ~ ~ ~ farmland run setblock ~ ~1 ~ light[level=6]
execute as @e[tag=luminous] at @s if score @s bananas matches 48000..96000 run fill ~ ~1 ~ ~ ~1 ~ air replace light[level=3]
execute as @e[tag=luminous] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:40}}}
execute as @e[tag=luminous] at @s if score @s bananas matches 96000.. run execute unless block ~ ~ ~ flower_pot unless block ~ ~ ~ lily_pad unless block ~ ~ ~ farmland run setblock ~ ~ ~ light[level=10]
execute as @e[tag=luminous] at @s if score @s bananas matches 96000.. run execute if block ~ ~ ~ flower_pot if block ~ ~ ~ lily_pad if block ~ ~ ~ farmland run setblock ~ ~1 ~ light[level=10]
execute as @e[type=marker,tag=luminous] at @s run function seed:plantas/luminous/luminousgen
execute as @e[type=marker,tag=luminous2] at @s run function seed:plantas/luminous/luminousgen2
execute as @e[tag=Luminous] at @s[tag=mini] unless entity @e[tag=luminous,distance=..0.5] run function seed:plantas/luminous/killminiluminous
execute as @e[tag=Luminous] at @s[tag=Grande] unless entity @e[tag=luminous,distance=..0.5] run function seed:plantas/luminous/killluminous
execute as @e[tag=Luminous] at @s[tag=terrestre] unless entity @e[tag=luminous2,distance=..0.5] run function seed:plantas/luminous/killluminous
execute as @e[tag=Luminous] at @s if data entity @s attack run kill @e[tag=luminous,distance=..0.5]
execute as @e[tag=Luminous] at @s if data entity @s attack run kill @e[tag=luminous2,distance=..0.5]
execute as @e[tag=luminous2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.3,0.0]},Tags:["tijera","luminous2","planta","terrestre"]}
execute as @e[tag=luminous] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","luminous","planta","terrestre"]}

#savagered

execute as @e[tag=savagered] at @s if score @s bananas matches 120000.. run function seed:plantas/savagered/savagered
execute as @e[tag=savagered] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:41}}}
execute as @e[tag=savagered] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:42}}}
execute as @e[tag=savagered] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:43}}}
execute as @e[type=marker,tag=savagered] at @s run function seed:plantas/savagered/savageredgen
execute as @e[tag=Savagered] at @s unless entity @e[tag=savagered,distance=..0.5] run function seed:plantas/savagered/killsavagered
execute as @e[tag=Savagered] at @s if data entity @s attack run kill @e[tag=savagered,distance=..0.5]
execute as @e[tag=savagered] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.35,0.0],scale:[0.5,0.5,0.5]},Tags:["tijera","savagered","planta","terrestre"]}

#purple

execute as @e[tag=Purple] at @s if score @e[tag=purple,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Purple","interactive","terrestre"]}
execute as @e[tag=Purple] at @s if score @e[tag=purple,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=purple] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:44}}}
execute as @e[tag=purple] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:45}}}
execute as @e[tag=purple] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:46}},Tags:["tijera","grande","purple","planta","terrestre"]}
execute as @e[type=marker,tag=purple] at @s run function seed:plantas/purple/purplegen
execute as @e[type=marker,tag=purple2] at @s run function seed:plantas/purple/purplegen2
execute as @e[tag=Purple] at @s[tag=mini] unless entity @e[tag=purple,distance=..0.5] run function seed:plantas/purple/killminipurple
execute as @e[tag=Purple] at @s[tag=Grande] unless entity @e[tag=purple,distance=..0.5] run function seed:plantas/purple/killpurple
execute as @e[tag=Purple] at @s if data entity @s attack run kill @e[tag=purple,distance=..0.5]
execute as @e[tag=Purple] at @s if data entity @s attack run kill @e[tag=purple2,distance=..0.5]
execute as @e[tag=purple2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:46}},Tags:["tijera","purple2","planta","terrestre"]}
execute as @e[tag=purple] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","purple","planta","terrestre"]}
execute as @e[tag=purple] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:46}},transformation:{translation:[0.0,0.0,0.0],scale:[1.0,1.0,1.0]},Tags:["tijera","grande","purple","planta","terrestre"]}

#majestic

execute as @e[tag=Majestic] at @s if score @e[tag=majestic,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {Tags:["Grande","Majestic","interactive","terrestre"]}
execute as @e[tag=Majestic] at @s if score @e[tag=majestic,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=majestic] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:47}}}
execute as @e[tag=majestic] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:48}}}
execute as @e[tag=majestic] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:49}}}
execute as @e[type=marker,tag=majestic] at @s run function seed:plantas/majestic/majesticgen
execute as @e[type=marker,tag=majestic2] at @s run function seed:plantas/majestic/majesticgen2
execute as @e[tag=Majestic] at @s[tag=mini] unless entity @e[tag=majestic,distance=..0.5] run function seed:plantas/majestic/killminimajestic
execute as @e[tag=Majestic] at @s[tag=Grande] unless entity @e[tag=majestic,distance=..0.5] run function seed:plantas/majestic/killmajestic
execute as @e[tag=Majestic] at @s if data entity @s attack run kill @e[tag=majestic,distance=..0.5]
execute as @e[tag=majestic] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.2,0.01],scale:[0.8,0.8,0.8]},Tags:["tijera","majestic","planta","terrestre"]}

#string

execute as @e[tag=String] at @s if score @e[tag=string,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {Tags:["Grande","String","interactive"]}
execute as @e[tag=String] at @s if score @e[tag=string,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=string] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:50}}}
execute as @e[tag=string] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:51}}}
execute as @e[tag=string] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:52}}}
execute as @e[type=marker,tag=string] at @s run function seed:plantas/string/stringgen
execute as @e[type=marker,tag=string2] at @s run function seed:plantas/string/stringgen2
execute as @e[tag=String] at @s[tag=mini] unless entity @e[tag=string,distance=..0.5] run function seed:plantas/string/killministring
execute as @e[tag=String] at @s[tag=Grande] unless entity @e[tag=string,distance=..0.5] run function seed:plantas/string/killstring
execute as @e[tag=String] at @s[tag=terrestre] unless entity @e[tag=string2,distance=..0.5] run function seed:plantas/string/killstring
execute as @e[tag=String] at @s if data entity @s attack run kill @e[tag=string,distance=..0.5]
execute as @e[tag=String] at @s if data entity @s attack run kill @e[tag=string2,distance=..0.5]
execute as @e[tag=string2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.3,0.0]},Tags:["tijera","string2","planta","terrestre"]}
execute as @e[tag=string] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","string","planta","terrestre"]}

#amazonic

execute as @e[tag=Amazonic] at @s if score @e[tag=amazonic,limit=1,distance=..0.5] bananas matches 96000.. run data merge entity @s {height:2.0,Tags:["Grande","Amazonic","interactive"]}
execute as @e[tag=Amazonic] at @s if score @e[tag=amazonic,limit=1,distance=..0.5] bananas matches 96000.. run tag @s remove mini
execute as @e[tag=amazonic] at @s if score @s bananas matches ..48000 run data merge entity @s {item:{tag:{CustomModelData:53}}}
execute as @e[tag=amazonic] at @s if score @s bananas matches 48000..96000 run data merge entity @s {item:{tag:{CustomModelData:54}}}
execute as @e[tag=amazonic] at @s if score @s bananas matches 96000.. run data merge entity @s {item:{tag:{CustomModelData:55}},Tags:["tijera","grande","amazonic","planta"]}
execute as @e[type=marker,tag=amazonic] at @s run function seed:plantas/amazonic/amazonicgen
execute as @e[type=marker,tag=amazonic2] at @s run function seed:plantas/amazonic/amazonicgen2
execute as @e[tag=Amazonic] at @s[tag=mini] unless entity @e[tag=amazonic,distance=..0.5] run function seed:plantas/amazonic/killminiamazonic
execute as @e[tag=Amazonic] at @s[tag=Grande] unless entity @e[tag=amazonic,distance=..0.5] run function seed:plantas/amazonic/killamazonic
execute as @e[tag=Amazonic] at @s[tag=terrestre] unless entity @e[tag=amazonic2,distance=..0.5] run function seed:plantas/amazonic/killamazonic
execute as @e[tag=Amazonic] at @s if data entity @s attack run kill @e[tag=amazonic,distance=..0.5]
execute as @e[tag=Amazonic] at @s if data entity @s attack run kill @e[tag=amazonic2,distance=..0.5]
execute as @e[tag=amazonic2] at @s if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:55}},Tags:["tijera","amazonic2","planta","terrestre"]}
execute as @e[tag=amazonic] at @s[tag=!grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {transformation:{translation:[-0.03,-0.1,0.0]},Tags:["tijera","amazonic","planta","terrestre"]}
execute as @e[tag=amazonic] at @s[tag=grande] if block ~ ~ ~ minecraft:flower_pot run data merge entity @s {item:{tag:{CustomModelData:55}},transformation:{translation:[0.0,0.0,0.0]},Tags:["tijera","grande","amazonic","planta","terrestre"]}
