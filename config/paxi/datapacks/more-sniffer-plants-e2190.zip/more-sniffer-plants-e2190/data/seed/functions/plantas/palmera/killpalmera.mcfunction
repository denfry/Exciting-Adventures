playsound minecraft:block.wood.break ambient @a ~ ~ ~ 1 0.9 1
particle item poppy{CustomModelData:2} ~ ~ ~ 0.3 0.5 0.3 0 20 force
summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["palmera"]},CustomModelData:1,display:{Name:'[{"text":"palm","italic":false}]'}}}}
kill @s