playsound minecraft:block.grass.break ambient @a ~ ~ ~ 1 0.9 1
particle item poppy{CustomModelData:55} ~ ~ ~ 0.3 0.5 0.3 0 20 force
summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["amazonic2"]},CustomModelData:31,display:{Name:'[{"text":"amazonic flower","italic":false}]'}}}}
kill @s