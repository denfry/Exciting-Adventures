execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:6}}}] run give @p minecraft:carrot_on_a_stick{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}
execute as @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:6}}}] at @s run data merge entity @s {item:{id:"minecraft:air",Count:1b,tag:{CustomModelData:1}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:5}}}] run give @p minecraft:carrot_on_a_stick{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}
execute as @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:5}}}] at @s run data merge entity @s {item:{tag:{CustomModelData:6}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:4}}}] run give @p minecraft:carrot_on_a_stick{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}
execute as @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:4}}}] at @s run data merge entity @s {item:{tag:{CustomModelData:5}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:3}}}] run give @p minecraft:carrot_on_a_stick{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}
execute as @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:3}}}] at @s run data merge entity @s {item:{tag:{CustomModelData:4}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] run give @p minecraft:carrot_on_a_stick{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}
execute as @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] at @s run data merge entity @s {item:{tag:{CustomModelData:3}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run give @p minecraft:carrot_on_a_stick{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}
execute as @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] at @s run data merge entity @s {item:{tag:{CustomModelData:2}}}
data remove entity @s interaction

