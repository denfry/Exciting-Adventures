playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:44}},Tags:["mini","purple","planta"]}
summon interaction ~ ~ ~ {Tags:["mini","Purple","terrestre","interactive"]}
 kill @s