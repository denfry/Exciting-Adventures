playsound minecraft:sniffer.banana player @a[distance=..10] ~ ~ ~ 1 1 1
item replace entity @s weapon.mainhand with apple{CustomModelData:7,display:{Name:'[{"text":"peeled banana","italic":false}]'}}
scoreboard players reset @s banana