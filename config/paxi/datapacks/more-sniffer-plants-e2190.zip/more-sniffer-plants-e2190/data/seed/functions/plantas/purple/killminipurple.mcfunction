playsound minecraft:block.grass.break ambient @a ~ ~ ~ 1 0.9 1
particle item poppy{CustomModelData:44} ~ ~ ~ 0.3 0.5 0.3 0 20 force
summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["purple"]},CustomModelData:24,display:{Name:'[{"text":"spore purple mushroom","italic":false}]'}}}}
kill @s