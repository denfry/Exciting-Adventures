playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:34}},Tags:["yellowsadness2","planta"]}
summon interaction ~ ~ ~ {Tags:["Yellowsadness","terrestre","interactive"]}
 kill @s