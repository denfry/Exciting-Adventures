playsound minecraft:block.grass.break ambient @a ~ ~ ~ 1 0.9 1
particle item poppy{CustomModelData:35} ~ ~ ~ 0.3 0.5 0.3 0 20 force
summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["cuenco"]},CustomModelData:19,display:{Name:'[{"text":"flower bowl seed","italic":false}]'}}}}
kill @s