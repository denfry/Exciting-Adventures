playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:47}},Tags:["majestic","planta"]}
summon interaction ~ ~ ~ {Tags:["mini","terrestre","Majestic","interactive"]}
 kill @s