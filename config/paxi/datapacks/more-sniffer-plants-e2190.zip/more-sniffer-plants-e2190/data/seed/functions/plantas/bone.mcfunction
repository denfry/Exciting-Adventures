playsound minecraft:item.bone_meal.use ambient @a ~ ~ ~ 1 1 1
particle minecraft:happy_villager ~ ~ ~ 0.3 0.2 0.0 0 50 force
execute as @e[tag=interactive,distance=..0.5] at @s on target run clear @s[gamemode=!creative] bone_meal 1
function seed:plantas/ejecutarrandom
execute as @e[tag=interactive,distance=..0.5] at @s run data remove entity @s interaction