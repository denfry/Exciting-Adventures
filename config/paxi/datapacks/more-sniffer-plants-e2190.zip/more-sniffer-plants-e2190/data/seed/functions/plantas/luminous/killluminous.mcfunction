playsound minecraft:block.grass.break ambient @a ~ ~ ~ 1 0.9 1
execute unless block ~ ~ ~ farmland run setblock ~ ~ ~ air
execute if block ~ ~ ~ farmland run setblock ~ ~1 ~ air
particle item poppy{CustomModelData:40} ~ ~ ~ 0.3 0.5 0.3 0 20 force
summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["luminous2"]},CustomModelData:22,display:{Name:'[{"text":"luminous flower","italic":false}]'}}}}
kill @s