execute as @e[tag=Wulu] at @s if data entity @s interaction run data merge entity @e[tag=wulu,nbt={item:{tag:{CustomModelData:18}}},distance=..0.8,limit=1] {item:{tag:{CustomModelData:19}}}
execute as @e[tag=Wulu] at @s if data entity @s interaction run scoreboard players set @e[tag=wulu,nbt={item:{tag:{CustomModelData:19}}},distance=..0.8,limit=1] bananas 24000
execute as @e[tag=Wulu] at @s on target run give @s cookie{CustomModelData:2,display:{Name:'[{"text":"wulu seed","italic":false}]'}} 1
data remove entity @s interaction
playsound minecraft:block.sweet_berry_bush.pick_berries ambient @a ~ ~ ~ 1 1 1