playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
execute unless block ~ ~ ~ flower_pot unless block ~ ~ ~ lily_pad unless block ~ ~ ~ water unless block ~ ~ ~ lava unless block ~ ~ ~ cauldron unless block ~ ~ ~ #slabs unless block ~ ~ ~ #stairs run setblock ~ ~ ~ minecraft:light[level=10]
execute if block ~ ~ ~ flower_pot if block ~ ~ ~ lily_pad run setblock ~ ~1 ~ minecraft:light[level=10]
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:40}},Tags:["luminous2","planta"]}
summon interaction ~ ~ ~ {Tags:["Luminous","terrestre","interactive"]}
 kill @s