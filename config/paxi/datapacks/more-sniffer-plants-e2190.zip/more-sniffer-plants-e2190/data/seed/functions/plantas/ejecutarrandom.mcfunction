function seed:plantas/random

execute if score rng# Random matches 1 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 1000
execute if score rng# Random matches 2 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 5000
execute if score rng# Random matches 3 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 10000
execute if score rng# Random matches 4 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 15000
execute if score rng# Random matches 5 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 20000
execute if score rng# Random matches 6 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 25000
execute if score rng# Random matches 7 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 30000
execute if score rng# Random matches 8 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 27000
execute if score rng# Random matches 9 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 18000
execute if score rng# Random matches 10 run scoreboard players add @e[tag=planta,distance=..0.5] bananas 85000

scoreboard players reset rng# Random