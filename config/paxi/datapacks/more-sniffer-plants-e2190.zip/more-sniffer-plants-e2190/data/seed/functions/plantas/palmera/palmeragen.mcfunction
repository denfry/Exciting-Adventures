playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:1}},Tags:["palmera","planta"]}
summon interaction ~ ~ ~ {Tags:["Palmera","mini","terrestre","interactive"]}
 kill @s