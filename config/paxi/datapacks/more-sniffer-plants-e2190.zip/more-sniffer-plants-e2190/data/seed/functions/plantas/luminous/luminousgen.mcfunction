playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
setblock ~ ~1 ~ minecraft:light[level=3]
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:38}},Tags:["luminous","planta"]}
summon interaction ~ ~ ~ {Tags:["Luminous","mini","interactive"]}
 kill @s