execute if block ~ ~ ~ water run playsound minecraft:entity.player.splash ambient @a ~ ~ ~ 1 1 1
playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:36}},Tags:["water","cuenco","planta","water"]}
execute as @e[tag=cuenco,distance=..0.5] at @s run scoreboard players set @s bananas 96000
execute as @e[distance=..0.5,tag=cuenco] at @s run data merge entity @s {transformation:{translation:[0.0,0.4,0.0]},interpolation_duration:3,start_interpolation:0}
summon interaction ~ ~ ~ {Tags:["water","Cuenco","mini","interactive"]}
 kill @s