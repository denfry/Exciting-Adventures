tellraw @a ["",{"text":"More Sniffer Plants","bold":true,"color":"gold"},{"text":"\n"},{"text":"Datapack by Kiwi_Arg:","color":"yellow"},{"text":" "},{"text":"[PlanetMinecraft]","bold":true,"color":"green","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/member/kiwi_arg/"}},{"text":"\n"},{"text":"ResorcePack by Torrezx:","color":"yellow"},{"text":" "},{"text":"[PlanetMinecraft]","bold":true,"color":"dark_aqua","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/member/torrezx/"}}]
scoreboard objectives add banana minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bananas dummy
scoreboard objectives add Random dummy
scoreboard objectives add spikeweed dummy