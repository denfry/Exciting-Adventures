#1
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:6}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}

#2
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:5}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:5}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}

#3
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:4}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:4}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:4}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}

#4
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:3}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:3}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:3}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:3}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}

#5
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:2}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}

#6
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}
execute if entity @e[tag=BananaGen,distance=..0.5,nbt={item:{tag:{CustomModelData:1}}}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:1,display:{Name:'[{"text":"banana","italic":false}]'}}}}

execute as @e[tag=BananaGen,distance=..0.5] at @s run data merge entity @s {item:{id:"minecraft:air",Count:1b,tag:{CustomModelData:1}}}
data remove entity @s attack

