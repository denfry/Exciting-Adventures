playsound minecraft:block.beehive.exit ambient @a ~ ~ ~ 1 1 1
kill @e[tag=Palmera,distance=..0.5]
place template structures:arboles/palmera ~-5 ~ ~-5
kill @s