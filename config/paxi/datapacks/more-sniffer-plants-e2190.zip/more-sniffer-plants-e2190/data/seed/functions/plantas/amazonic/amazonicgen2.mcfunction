playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:55}},Tags:["amazonic2","planta"]}
summon interaction ~ ~ ~ {height:2.0,Tags:["Amazonic","terrestre","interactive"]}
 kill @s