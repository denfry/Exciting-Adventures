playsound minecraft:block.beehive.exit ambient @a ~ ~ ~ 1 1 1
kill @e[tag=Savagered,distance=..0.5]
place template structures:arboles/hongos ~-8 ~ ~-8
kill @s