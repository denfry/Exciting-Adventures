playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:25}},Tags:["spikeweed2","planta"]}
summon interaction ~ ~ ~ {Tags:["Spikeweed","terrestre","interactive"]}
 kill @s