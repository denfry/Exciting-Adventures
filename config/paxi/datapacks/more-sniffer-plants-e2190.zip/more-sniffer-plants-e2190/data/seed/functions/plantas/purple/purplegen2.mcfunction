playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:46}},Tags:["Grande","purple","planta"]}
summon interaction ~ ~ ~ {Tags:["Grande","Purple","terrestre","interactive"]}
scoreboard players set @e[distance=..0.5,tag=purple] bananas 96000
 kill @s