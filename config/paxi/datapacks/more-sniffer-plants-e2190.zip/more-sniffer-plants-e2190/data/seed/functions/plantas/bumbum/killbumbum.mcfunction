playsound minecraft:block.sweet_berry_bush.break ambient @a ~ ~ ~ 1 0.9 1
particle item poppy{CustomModelData:3} ~ ~ ~ 0.3 0.5 0.3 0 20 force
summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:creeper_spawn_egg",Count:1b,tag:{EntityTag:{id:"minecraft:marker",Tags:["bumbum"]},CustomModelData:2,display:{Name:'[{"text":"bumbum berries","italic":false}]'}}}}
kill @s