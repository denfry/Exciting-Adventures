playsound minecraft:block.grass.place ambient @a ~ ~ ~ 1 0.9 1
summon item_display ~ ~0.5 ~ {item:{id:"minecraft:poppy",Count:1b,tag:{CustomModelData:12}},Tags:["amber2","planta"]}
summon interaction ~ ~ ~ {Tags:["Amber","terrestre","interactive"]}
execute as @e[tag=Amber,distance=..0.5] at @s run data merge entity @s {height:2.0}
 kill @s