execute as @e[tag=Bumbum] at @s if data entity @s interaction run data merge entity @e[tag=bumbum,nbt={item:{tag:{CustomModelData:5}}},distance=..0.8,limit=1] {item:{tag:{CustomModelData:6}}}
execute as @e[tag=Bumbum] at @s if data entity @s interaction run scoreboard players set @e[tag=bumbum,nbt={item:{tag:{CustomModelData:6}}},distance=..0.8,limit=1] bananas 24000
execute as @e[tag=Bumbum] at @s on target run give @s cookie{CustomModelData:1,display:{Name:'[{"text":"bumbum_berries","italic":false}]'}} 4
data remove entity @s interaction
playsound minecraft:block.sweet_berry_bush.pick_berries ambient @a ~ ~ ~ 1 1 1