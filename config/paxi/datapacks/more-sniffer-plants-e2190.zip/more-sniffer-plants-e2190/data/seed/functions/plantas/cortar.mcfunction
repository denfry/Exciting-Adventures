playsound entity.sheep.shear ambient @a ~ ~ ~ 1 1 1
particle falling_spore_blossom ~ ~ ~ 0.3 0.5 0.0 0 50 force
tag @s add tijera
execute as @e[tag=interactive,distance=..0.5] at @s run data remove entity @s interaction