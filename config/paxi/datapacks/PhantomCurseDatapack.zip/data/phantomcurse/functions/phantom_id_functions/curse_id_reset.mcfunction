scoreboard players set #phantomidlist phantom_id 0
scoreboard players set @s phantom_id 0

tag @s remove phantom_tag
advancement revoke @s only phantomcurse:curse_id_reset

say reset