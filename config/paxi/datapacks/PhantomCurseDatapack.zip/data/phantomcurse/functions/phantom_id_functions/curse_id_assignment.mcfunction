#adds 1 point to a fake player (#phantomidlist) to use as a dynamic ID
scoreboard players add #phantomidlist phantom_id 1

#assigns untagged player with that ID number and tags them to avoid re-scoring
scoreboard players operation @s[tag=phantom_cursed,tag=!phantom_tag] phantom_id = #phantomidlist phantom_id
tag @s add phantom_tag