tp @s ~ ~0.2 ~
tellraw @s "You can't fall asleep..."
advancement revoke @s only phantomcurse:no_sleep