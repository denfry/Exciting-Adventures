#reset scores and advancements
scoreboard players set @s phantom_eye_eaten 0
advancement revoke @s only phantomcurse:phantom_eye_sleeping/phantom_eye_reward


effect clear @s nausea

#spawn loot item entity at player
loot spawn ~ ~0.5 ~ loot phantomcurse:phantom_eye_rewards
tellraw @p {"text":"You found an item from your dream...","color":"aqua"}

advancement grant @s only phantomcurse:new_advancements/treasure_haunter