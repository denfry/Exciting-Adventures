playsound minecraft:block.honey_block.break player @s ~ ~ ~ 1 1.5
scoreboard players add @s phantom_eye_eaten 600
effect clear @s poison
effect give @s nausea 30 1

advancement revoke @s only phantomcurse:phantom_eye_sleeping/phantom_eye_eaten
