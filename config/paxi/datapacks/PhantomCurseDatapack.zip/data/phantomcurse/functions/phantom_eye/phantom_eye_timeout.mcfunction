advancement revoke @s only phantomcurse:phantom_eye_sleeping/phantom_eye_slept
advancement revoke @s only phantomcurse:phantom_eye_sleeping/phantom_eye_eaten
effect clear @s nausea
scoreboard players set @s phantom_eye_eaten 0