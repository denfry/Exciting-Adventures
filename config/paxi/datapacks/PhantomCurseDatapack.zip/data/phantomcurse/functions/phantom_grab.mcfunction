tp @s @e[type=phantom,limit=1,sort=nearest,distance=..2]
execute on attacker run particle dust 0.81 0.25 0.47 1 ~ ~ ~ 0.5 0.5 0.5 0.1 5 normal
scoreboard players remove @s phantom_grabbed 1
advancement revoke @s only phantomcurse:phantom_grab