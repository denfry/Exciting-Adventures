#scoreboard players set @s phantom_curse_time 24001
#scoreboard players set @s phantom_kill_count 4

scoreboard players set @s phantom_curse_time 10001
scoreboard players set @s phantom_respawn_timer 0
time set 13250