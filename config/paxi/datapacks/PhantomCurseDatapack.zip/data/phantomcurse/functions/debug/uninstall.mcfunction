scoreboard objectives remove phantom_count
scoreboard objectives remove phantom_curse_time
scoreboard objectives remove phantom_eye_eaten
scoreboard objectives remove phantom_id
scoreboard objectives remove phantom_respawn_timer
scoreboard objectives remove time_since_death

tag @s remove phantom_cursed
tag @s remove phantom_tag