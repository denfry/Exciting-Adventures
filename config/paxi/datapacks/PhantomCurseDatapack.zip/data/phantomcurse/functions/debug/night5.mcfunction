#scoreboard players set @s phantom_curse_time 72001
#scoreboard players set @s phantom_kill_count 4

scoreboard players set @s phantom_curse_time 30001
scoreboard players set @s phantom_respawn_timer 0
time set 13250