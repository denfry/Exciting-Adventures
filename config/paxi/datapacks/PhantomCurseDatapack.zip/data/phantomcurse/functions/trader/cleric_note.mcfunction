tellraw @s {"text":"The Cleric hands you a note.","color":"white"}

playsound minecraft:entity.villager.yes neutral @s ~ ~ ~ 1 1
playsound minecraft:entity.villager.work_librarian neutral @s ~ ~ ~ 1 1
playsound minecraft:entity.villager.work_cartographer neutral @s ~ ~ ~ 1 1
summon item ~ ~ ~ {Item:{id:"minecraft:paper",Count:1b,tag:{display:{Name:'{"text":"Suspicious Note","italic":false}',Lore:['{"text":" "}','{"text":" "}','{"text":" "}','{"text":" "}','{"text":" "}','{"text":" "}','{"text":"ᵯ","color":"white","italic":false}']},CustomModelData:1001,sus_note:1}}}

scoreboard players set @s sus_note_cooldown 24000
advancement revoke @s only phantomcurse:trader/cleric_note