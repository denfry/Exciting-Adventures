tellraw @p ["",{"text":"[","color":"white"},{"text":"Phantom Curse","bold":true,"color":"aqua"},{"text":", By: SixFootBlue]","color":"white"}," has loaded. Vanilla phantom spawning is now disabled.","\n","Click ",{"text":"[HERE]","bold":true,"color":"red","clickEvent":{"action":"run_command","value":"/function phantomcurse:uninstall"}},{"text":" to uninstall.","color":"white"}]

#Timer for suspicious note cooldown
scoreboard objectives add sus_note_cooldown dummy

#Timer for how long until release after a phantom grabs you
scoreboard objectives add phantom_grabbed dummy

#Timer tracking how long a player is cursed in ticks
scoreboard objectives add phantom_curse_time dummy

#Timer tracking when phantoms should respawn in ticks
scoreboard objectives add phantom_respawn_timer dummy

#Score tracking number of phantoms killed (Might be phased out)
scoreboard objectives add phantom_kill_count dummy


#Score assigning a numerical ID to each player and their corresponding phantom swarm.
scoreboard objectives add phantom_id dummy

#Score for counting remaining living phantoms for their respective cursed player.
scoreboard objectives add phantom_count dummy


#Score for how long an eaten phantom eye remains in effect
scoreboard objectives add phantom_eye_eaten dummy

#Score for tracking time since death
scoreboard objectives add time_since_death minecraft.custom:minecraft.time_since_death

#Toggle for curse clear on death
#scoreboard objectives add curse_death_toggle dummy

gamerule doInsomnia false