tag @s remove phantom_cursed
tag @s remove phantom_tag
scoreboard players set @s phantom_id 0
scoreboard players set @s phantom_curse_time 0
scoreboard players set @s phantom_respawn_timer 0

advancement revoke @s only phantomcurse:curse_death/curse_death
#say uncursed