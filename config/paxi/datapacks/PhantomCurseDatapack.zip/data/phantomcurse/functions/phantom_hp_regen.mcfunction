execute on attacker run effect give @s[tag=curse_mob] minecraft:regeneration 2 3
playsound minecraft:entity.witch.drink hostile @s ~ ~ ~ 1 1

