#resets counter score for phantom counting
scoreboard players set @s phantom_count 0

#execute as @e[type=phantom,limit=3,distance=..100,tag=curse_mob,tag=phantom_tag,tag=curse_changed] if score @s phantom_id = @p phantom_id run scoreboard players add @p phantom_count 1
execute at @e[type=phantom,limit=3,distance=..60,tag=curse_mob,tag=phantom_tag,tag=curse_changed] if score @e[type=phantom,limit=1,sort=nearest,tag=phantom_tag] phantom_id = @s phantom_id run scoreboard players add @s phantom_count 1

#Summons phantoms according to count score. Invisible and invulnerable.
execute if score @s phantom_count matches ..2 run summon phantom ~ ~-0.2 ~ {Invulnerable:1b,NoAI:1b,Size:0,Tags:["curse_mob"],ActiveEffects:[{Id:14,Amplifier:1b,Duration:30,ShowParticles:0b}],Attributes:[{Name:generic.follow_range,Base:240}]}
execute if score @s phantom_count matches ..1 run summon phantom ~ ~-0.2 ~ {Invulnerable:1b,NoAI:1b,Size:0,Tags:["curse_mob"],ActiveEffects:[{Id:14,Amplifier:1b,Duration:30,ShowParticles:0b}],Attributes:[{Name:generic.follow_range,Base:240}]}
execute if score @s phantom_count matches ..0 run summon phantom ~ ~-0.2 ~ {Invulnerable:1b,NoAI:1b,Size:0,Tags:["curse_mob"],ActiveEffects:[{Id:14,Amplifier:1b,Duration:30,ShowParticles:0b}],Attributes:[{Name:generic.follow_range,Base:240}]}

#Updates their IDs to match player ID
execute as @e[type=phantom,sort=nearest,limit=3,tag=curse_mob,tag=!phantom_tag,tag=!curse_changed] run scoreboard players operation @s phantom_id = @p phantom_id

#Updates their tags
tag @e[type=phantom,sort=nearest,limit=3,tag=curse_mob,tag=!phantom_tag,tag=!curse_changed] add phantom_tag
execute as @e[type=phantom,sort=nearest,limit=3,tag=curse_mob,tag=phantom_tag,tag=!curse_changed] run data merge entity @s {Invulnerable:0b,NoAI:0b}
tag @e[type=phantom,sort=nearest,limit=3,tag=curse_mob,tag=phantom_tag,tag=!curse_changed] add curse_changed

#Teleports them to designated position above player/world surface
execute as @e[type=phantom,sort=nearest,limit=3,tag=curse_mob,tag=phantom_tag,tag=curse_changed] positioned over motion_blocking run tp @s ~ ~25 ~


scoreboard players set @s phantom_respawn_timer 3000
advancement revoke @s only phantomcurse:phantom_summoning/phantoms_night_2

