#Spawn unchanged phantom
#summon minecraft:phantom ~ ~20 ~ {Tags:["curse_mob"]}

#Chance modify phantom
#execute as @e[type=minecraft:phantom,tag=curse_mob,tag=!curse_changed,sort=nearest,limit=1] if predicate phantomcurse:big_phantom_chance run data merge entity @s[tag=curse_mob,tag=!curse_changed] {DeathLootTable:"phantomcurse:entities/big_phantom",Size:6,Tags:["curse_changed"]}
#execute as @e[type=minecraft:phantom,tag=curse_mob,tag=!curse_changed,sort=nearest,limit=1] run tag @s add curse_changed

