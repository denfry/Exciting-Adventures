playsound minecraft:entity.phantom.ambient hostile @s ~ ~10 ~ 1 1

scoreboard players set @s phantom_respawn_timer 3000
advancement revoke @s only phantomcurse:phantom_summoning/phantoms_night_1