#for counting total ticks of curse time
#scoreboard players add @a[tag=phantom_cursed,scores={phantom_curse_time=..72001}] phantom_curse_time 1
#scoreboard players add @a[tag=phantom_cursed,scores={phantom_curse_time=..72001},predicate] phantom_curse_time 1
scoreboard players add @a[tag=phantom_cursed,scores={phantom_curse_time=..30001},predicate=phantomcurse:night_check] phantom_curse_time 1

#for counting down the phantom respawn timer unless the value is 0
#execute as @a[tag=phantom_cursed,scores={phantom_respawn_timer=1..}] if predicate phantomcurse:night_check run 
scoreboard players remove @a[tag=phantom_cursed,scores={phantom_respawn_timer=1..},predicate=phantomcurse:night_check] phantom_respawn_timer 1

#timer for how long a player is able to get a phantom eye reward before dawn
scoreboard players remove @a[scores={phantom_eye_eaten=1..}] phantom_eye_eaten 1

#timer for cooldown time before clerics give you another suspicious note
scoreboard players remove @a[scores={sus_note_cooldown=1..}] sus_note_cooldown 1