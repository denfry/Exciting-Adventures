execute if block ~ ~ ~ minecraft:water_cauldron[level=1] run setblock ~ ~ ~ minecraft:cauldron replace
execute if block ~ ~ ~ minecraft:water_cauldron[level=2] run setblock ~ ~ ~ minecraft:water_cauldron[level=1] replace
execute if block ~ ~ ~ minecraft:water_cauldron[level=3] run setblock ~ ~ ~ minecraft:water_cauldron[level=2] replace

playsound minecraft:block.brewing_stand.brew block @a ~ ~ ~ 1 1
playsound minecraft:entity.zombie.converted_to_drowned block @a ~ ~ ~ 1 1
particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.2 0.2 0.2 0.01 25 normal
summon item ~ ~ ~ {Motion:[0.0,0.3,0.0],Tags:["phantom_antidote","phantom_antidote_new"],Item:{id:"minecraft:honey_bottle",Count:1b,tag:{display:{Name:'{"text":"Slumber Syrup","color":"aqua","italic":false}'},CustomModelData:1000,slumber_syrup:1}}}

execute as @e[type=item,tag=phantom_antidote,tag=phantom_antidote_new] at @s run kill @e[type=item,sort=nearest,limit=1,tag=!phantom_antidote,nbt={Item:{id:"minecraft:honey_bottle",Count:1b}}]
execute as @e[type=item,tag=phantom_antidote,tag=phantom_antidote_new] at @s run kill @e[type=item,sort=nearest,limit=1,nbt={Item:{id:"minecraft:pitcher_plant",Count:1b}}]
execute as @e[type=item,tag=phantom_antidote,tag=phantom_antidote_new] at @s run kill @e[type=item,sort=nearest,limit=1,nbt={Item:{id:"minecraft:paper",Count:1b,tag:{ectoplasm:1}}}]

execute as @e[type=item,tag=phantom_antidote,tag=phantom_antidote_new] run tag @s remove phantom_antidote_new