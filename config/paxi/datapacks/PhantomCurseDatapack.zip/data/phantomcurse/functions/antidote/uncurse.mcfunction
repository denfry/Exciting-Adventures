particle minecraft:glow ~ ~1.5 ~ 0.5 0.5 0.5 0.1 25 normal
playsound minecraft:entity.allay.ambient_without_item player @s ~ ~ ~ 2 2
playsound minecraft:item.bottle.empty player @s ~ ~ ~ 2 0.75


tag @s remove phantom_cursed
tag @s remove phantom_tag
scoreboard players set @s phantom_id 0
scoreboard players set @s phantom_curse_time 0
scoreboard players set @s phantom_respawn_timer 0
scoreboard players set @s sus_note_cooldown 0

advancement revoke @s only phantomcurse:curse_cure
advancement grant @s only phantomcurse:new_advancements/exorcist