gamerule doInsomnia true
tellraw @a {"text":"Vanilla Phantom Spawning is re-enabled.","color":"white"}