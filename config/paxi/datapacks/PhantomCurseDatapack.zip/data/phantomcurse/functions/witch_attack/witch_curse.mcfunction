#execute if entity @e[type=potion,limit=1,sort=nearest,distance=..2] run say wah
execute on attacker at @s run particle minecraft:reverse_portal ~ ~0.2 ~ 0.5 0.3 0.5 0.02 50 normal
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 1 0.5

scoreboard players set @s phantom_curse_time 0
scoreboard players set @s phantom_respawn_timer 0
tag @s add phantom_cursed
effect give @s blindness 1 1

#execute on attacker run execute on target run say cursed
#say test

scoreboard players set @s sus_note_cooldown 0

advancement grant @s only phantomcurse:new_advancements/sleepless