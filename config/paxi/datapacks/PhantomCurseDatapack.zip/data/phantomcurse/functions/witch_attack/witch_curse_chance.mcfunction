execute as @s[tag=!phantom_cursed] if predicate phantomcurse:curse_chance run function phantomcurse:witch_attack/witch_curse
advancement revoke @s only phantomcurse:witch_attack