execute if predicate phantomcurse:grab_chance run scoreboard players add @s phantom_grabbed 21
execute if score @s phantom_grabbed matches 1..21 run function phantomcurse:phantom_hp_regen



advancement revoke @s only phantomcurse:phantom_attacked

#execute as @e[type=witch] at @e[type=potion,limit=1,sort=nearest] on target run execute as @e[type=potion] if entity @e[type=player,limit=1,sort=nearest,distance=..1] run say wah2


#execute as @e[type=witch] on target run execute as @s if entity @e[type=potion,limit=1,sort=nearest] run say wah3

#execute as @e[type=witch] on target run execute as @s if entity @e[type=potion,limit=1,sort=nearest,distance=..1] run say wah