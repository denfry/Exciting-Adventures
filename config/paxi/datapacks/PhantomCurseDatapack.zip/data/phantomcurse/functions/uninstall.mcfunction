scoreboard objectives remove phantom_count
scoreboard objectives remove phantom_curse_time
scoreboard objectives remove phantom_eye_eaten
scoreboard objectives remove phantom_grabbed
scoreboard objectives remove phantom_id
scoreboard objectives remove phantom_respawn_timer
scoreboard objectives remove sus_note_cooldown
scoreboard objectives remove time_since_death
scoreboard objectives remove phantom_kill_count

tellraw @a ["",{"text":"Phantom Curse","bold":true,"color":"aqua"},{"text":" was successfully uninstalled."}]
tellraw @a ["",{"text":"Click ","color":"white"},{"text":"[HERE]","bold":true,"color":"green","clickEvent":{"action":"run_command","value":"/function phantomcurse:enable_insomnia"}},{"text":" to re-enable vanilla phantom spawning.","color":"white"}]